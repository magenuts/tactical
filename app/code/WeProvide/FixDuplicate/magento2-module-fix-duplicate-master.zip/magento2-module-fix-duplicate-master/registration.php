<?php

use Magento\Framework\Component\ComponentRegistrar;
ComponentRegistrar::register(
    ComponentRegistrar::MODULE,
    'WeProvide_FixDuplicate',
    __DIR__
);
