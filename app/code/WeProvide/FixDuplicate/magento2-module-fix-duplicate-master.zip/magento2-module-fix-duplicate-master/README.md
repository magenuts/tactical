# Magento2 Fix Duplicate for linked product(s)

## Installation

1. `composer require weprovide/magento2-module-fix-duplicate`
2. Run `bin/magento setup:upgrade`

## Issue
[#6957](https://github.com/magento/magento2/issues/6764) Duplicate issue with linked products | [More information](https://github.com/magento/magento2/issues/6764)


---

Maintained by [We/Provide](https://www.weprovide.com/)
